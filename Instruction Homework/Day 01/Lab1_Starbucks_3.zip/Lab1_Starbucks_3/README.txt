


Context listener invokes factory for DataFacade
TestDataImpl is Singleton

final List of Coffees is "COLOR" coded to exercise JSTL

Uses "virtual" URIs [e.g.,  /action/login ]...to hide source details




INTERNAL NOTE: Similar to.. 3LS_Starbucks_Layer3 
[ accesses factory differently - through listener..]