

Test for null by  parseInt(add1);
and
catch exception